CREATE TABLE address (id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY, firstname VARCHAR(30), lastname VARCHAR(30), phone VARCHAR(30), email VARCHAR(30));
INSERT INTO address (firstname, lastname, phone, email) VALUES ( "Roberto", "Johnson", "123-456-7890", "roberto@someaddress.com"), ( "Jane", "Doe", "010-110-1101", "janedoe@someotheraddress.org" );
